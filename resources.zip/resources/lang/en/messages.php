<?php

return [
    'Select Employee' => 'Select Employee',
    'Dashboard' => 'Dashboard',
    
];